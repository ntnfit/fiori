sap.ui.define([
    "./MyController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/mvc/Controller"
], function (MyController, JSONModel, Controller) {
	"use strict";

	return MyController.extend("com.bosch.sbs.sbsfioritemplate.ui.controller.FlexibleColumnLayout", {
		onInit: function () {
			
		},

		onAfterRendering: function () {
			
		}
	});
});
