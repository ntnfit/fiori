sap.ui.define([
    "com/bosch/sbs/sbsfioritemplate/ui/test/unit/controller/App.controller",
    "com/bosch/sbs/sbsfioritemplate/ui/test/unit/controller/MyController",
    "com/bosch/sbs/sbsfioritemplate/ui/test/unit/controller/purchaseOrderMaster.controller",
    "com/bosch/sbs/sbsfioritemplate/ui/test/unit/controller/BaseController"
], function () {
	"use strict";
});
