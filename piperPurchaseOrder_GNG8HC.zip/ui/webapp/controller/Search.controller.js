sap.ui.define([
	"./MyController",
	'sap/ui/core/Fragment',
	"sap/ui/core/ValueState",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Text"
], function (MyController, Fragment , ValueState, Dialog, DialogType, Button, ButtonType, Text) {
	"use strict";

	return MyController.extend("com.bosch.sbs.sbsfioritemplate.ui.controller.Search", {

		onInit: function (oEvent) {
		},

		

	});

});