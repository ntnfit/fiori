sap.ui.define([
	"./MyController"
], function (MyController) {
	"use strict";

	return MyController.extend("com.bosch.sbs.sbsfioritemplate.ui.controller.Welcome", {
		onInit: function(){
			
		}
	});
});